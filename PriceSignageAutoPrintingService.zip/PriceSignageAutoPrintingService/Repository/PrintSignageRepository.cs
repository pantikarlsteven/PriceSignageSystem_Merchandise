﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using PriceSignageSystem.Code;
using PriceSignageSystem.Helper;
using PriceSignageSystem.Models;
using PriceSignageSystem.Models.Constants;
using PriceSignageSystem.Models.DatabaseContext;
using PriceSignageSystem.Models.Dto;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceSignageAutoPrintingService.Repository
{
    public interface IPrintSignageRepository
    {
        AutoPrintStatusDto PrintStatus();
        void Print(List<decimal> skuList);
        List<decimal> GetSKUs(string sp, decimal o3Date);
    }

    public class PrintSignageRepository : IPrintSignageRepository
    {
        private readonly ApplicationDbContext _db;
        private readonly string connectionString;
        private readonly int storeId;
        private readonly string printerLocation;
        private readonly string printer;

        public PrintSignageRepository()
        {
            connectionString = ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString;
            storeId = int.Parse(ConfigurationManager.AppSettings["StoreID"]);
            printerLocation = ConfigurationManager.AppSettings["PrinterLocation"];
            printer = ConfigurationManager.AppSettings["Printer"];
            _db = new ApplicationDbContext();
        }

        public void AddMultipleInventoryPrintingLog(List<decimal> skuList, string user)
        {
            WriteToFile.Log("Start add inventory printing logs");
            foreach (var item in skuList)
            {
                _db.InventoryPrintingLogs.Add(new InventoryPrintingLog()
                {
                    O3SKU = item,
                    PrintedBy = user,
                    DateCreated = DateTime.Now
                });
            }
            _db.SaveChanges();
            WriteToFile.Log("end add inventory printing logs");
        }

        public List<ReportDto> GetReportDataList(List<decimal> skuList)
        {
            var data = new List<ReportDto>();
            try
            {
                data = (from a in _db.STRPRCs
                        join b in _db.Countries on a.O3TRB3 equals b.iatrb3 into ab
                        from c in ab.DefaultIfEmpty()
                        where skuList.Contains(a.O3SKU)
                        select new ReportDto
                        {
                            O3LOC = a.O3LOC,
                            O3CLAS = a.O3CLAS,
                            O3IDSC = a.O3IDSC,
                            O3SKU = a.O3SKU,
                            O3SCCD = a.O3SCCD,
                            O3UPC = a.O3UPC,
                            O3VNUM = a.O3VNUM,
                            O3TYPE = a.O3TYPE,
                            O3DEPT = a.O3DEPT,
                            O3SDPT = a.O3SDPT,
                            O3SCLS = a.O3SCLS,
                            O3POS = a.O3POS,
                            O3POSU = a.O3POSU,
                            O3REG = a.O3REG,
                            O3REGU = a.O3REGU,
                            O3ORIG = a.O3ORIG,
                            O3ORGU = a.O3ORGU,
                            O3EVT = a.O3EVT,
                            O3PMMX = a.O3PMMX,
                            O3PMTH = a.O3PMTH,
                            O3PDQT = a.O3PDQT,
                            O3PDPR = a.O3PDPR,
                            O3SDT = a.O3SDT,
                            O3EDT = a.O3EDT,
                            O3TRB3 = a.O3TRB3,
                            O3FGR = a.O3FGR,
                            O3FNAM = a.O3FNAM,
                            O3MODL = a.O3MODL,
                            O3LONG = a.O3LONG,
                            O3SLUM = a.O3SLUM,
                            O3DIV = a.O3DIV,
                            O3TUOM = a.O3TUOM,
                            O3DATE = a.O3DATE,
                            O3CURD = a.O3CURD,
                            O3USER = a.O3USER,
                            DateUpdated = a.DateUpdated,
                            TypeId = a.TypeId,
                            SizeId = a.SizeId,
                            CategoryId = a.CategoryId,
                            country_img = c.country_img
                        }).ToList();
            }
            catch (Exception ex)
            {
                WriteToFile.Log(ex.Message);
            }

            return data;
        }

        public List<decimal> GetSKUs(string sp, decimal o3Date)
        {
            List<decimal> skuList = new List<decimal>();
            using (var connection = new SqlConnection(connectionString))
            using (var command = new SqlCommand(sp, connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@loc", SqlDbType.Int).Value = storeId;
                command.Parameters.Add("@sdt", SqlDbType.Int).Value = o3Date;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    skuList.Add((decimal)reader["O3SKU"]);
                }
                reader.Close();
                connection.Close();
            }
            return skuList;
        }

        public void Print(List<decimal> skuList)
        {
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            WriteToFile.Log(baseDirectory);
            var pdfPath = @"C:\Services\PriceSignageAutoPrintingService\Reports\";
            var path = @"C:\Users\skarl\source\repos\vs2019\PriceSignageSystem\PriceSignageSystem\Reports\CrystalReports\";
            //var pdfPath = @"C:\users\syste\source\repos\PriceSignageSystem_dotnet4\PriceSignageSystem_dotnet4\PriceSignageAutoPrintingService\Reports\";
            //var path = @"C:\users\syste\source\repos\PriceSignageSystem_dotnet4\PriceSignageSystem_dotnet4\PriceSignageSystem\Reports\CrystalReports\";
            var user = "Admin";
            try
            {
                if (skuList.Count > 0)
                {
                    var data = GetReportDataList(skuList);
                    foreach (var item in data)
                    {
                        item.UserName = user;
                        var textToImage = new TextToImage();
                        textToImage.GetImageWidth(item.O3FNAM, item.O3IDSC, ReportConstants.Size.Skinny);
                        item.IsSLBrand = textToImage.IsSLBrand;
                        item.IsSLDescription = textToImage.IsSLDescription;
                    }
                    var dataTable = ConversionHelper.ConvertListToDataTable(data);
                    var reportPath = string.Empty;
                    reportPath = path + "Dynamic_SkinnyReport.rpt";
                    WriteToFile.Log(reportPath);

                    ReportDocument report = new ReportDocument();
                    report.Load(reportPath);
                    report.SetDataSource(dataTable);
                    Guid guid = Guid.NewGuid();
                    var pdf = pdfPath + guid + ".pdf";

                    //Export report to pdf
                    ExportOptions CrExportOptions;
                    DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
                    PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
                    CrDiskFileDestinationOptions.DiskFileName = pdf;
                    WriteToFile.Log(CrDiskFileDestinationOptions.DiskFileName);
                    CrExportOptions = report.ExportOptions;
                    {
                        CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
                        CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                        CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
                        CrExportOptions.FormatOptions = CrFormatTypeOptions;
                    }
                    report.Export();
                    string pdfArguments = string.Format(" /t \"{0}\\{1}.pdf\" \"{2}\"", pdfPath, guid, printer);
                    ProcessStartInfo newProcess = new ProcessStartInfo(printerLocation, pdfArguments);
                    newProcess.CreateNoWindow = true;
                    newProcess.RedirectStandardOutput = true;
                    newProcess.UseShellExecute = false;

                    Process pdfProcess = new Process();
                    pdfProcess.StartInfo = newProcess;
                    pdfProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    pdfProcess.Start();
                    WriteToFile.Log("Start printing");
                    UpdatePrintStatus();
                    pdfProcess.WaitForExit();

                    report.Close();
                    report.Dispose();

                    //UpdateMultipleStatus(skuList);
                    //AddMultipleInventoryPrintingLog(o3skus, user);

                }
                else
                    throw new Exception("No Selected Id");
            }
            catch (Exception ex)
            {
                WriteToFile.Log(ex.Message);
            }
        }

        public AutoPrintStatusDto PrintStatus()
        {
            var dto = new AutoPrintStatusDto();
            using (var connection = new SqlConnection(connectionString))
            try
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT TOP 1 * FROM AutoPrintStatus", connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            dto.IsPrinted = reader.GetBoolean(0);
                            dto.O3DATE = reader.GetDecimal(1);
                        }
                        else
                        {
                            dto.IsPrinted = false;
                            dto.O3DATE = 999999;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            return dto;
        }

        public void UpdatePrintStatus()
        {
            WriteToFile.Log("Start update autoprint IsPrinted status");
            using (var connection = new SqlConnection(connectionString))
            try
            {
                connection.Open();
                string sqlUpdateQuery = "UPDATE AutoPrintStatus SET IsPrinted = 1";

                using (SqlCommand command = new SqlCommand(sqlUpdateQuery, connection))
                {
                    int rowsAffected = command.ExecuteNonQuery();

                    WriteToFile.Log("IsPrinted status set to 1");
                }
            }
            catch (Exception ex)
            {
                WriteToFile.Log(ex.Message);
            }
            WriteToFile.Log("end");
        }

        public void UpdateMultipleStatus(List<decimal> skuList)
        {
            WriteToFile.Log("Start update strprc and strprclogs IsPrinted status");
            foreach (var item in skuList)
            {
                var data = _db.STRPRCs.Where(a => a.O3SKU == item).FirstOrDefault();
                data.IsPrinted = true;

                var logs = _db.STRPRCLogs.Where(a => a.O3SKU == item).ToList();

                foreach (var log in logs)
                {
                    log.IsPrinted = true;
                }
            }
            _db.SaveChanges();
            WriteToFile.Log("end");
        }
    }
}
